document.addEventListener('DOMContentLoaded', function() {
    let openShopping = document.querySelector('.shopping');
    let closeShopping = document.querySelector('.closeShopping');
    let body = document.querySelector('body');
    let quantitySpan = document.querySelector('.quantity');
    let productContainer = document.querySelector('.products');
    let shoppingList = document.querySelector('.listCard');
    let finishButton = document.querySelector('.total');
 
    const pageRefreshed = sessionStorage.getItem('pageRefreshed');
    if (!pageRefreshed) {
        // Clear sessionStorage on page load if not refreshed
        sessionStorage.clear();
    }
    sessionStorage.setItem('pageRefreshed', 'false');



    //otevírání a zavírání košíku
    openShopping.addEventListener('click', () => {
        if (isLoggedIn === true) {
            body.classList.add('active');
        } else {
            alert('Pro přístup do košíku je potřeba být přihlášen.');
        }
    });
    
    closeShopping.addEventListener('click', () => { //kliknu na box "Zavřít" a zavřu okno košík
        body.classList.remove('active');
    });

    //tvoření divů s položkami
    const productsData = [
        {
            id: 1,
            name: "AUTO",
            description: "Pořádně rychlá kára.",
            price: "100000 kč",
            //imageSrc: "auto.jpg",
        },
        {
            id: 2,
            name: "TRAKTOR",
            description: "Traktor pro pořádné farmáře.",
            price: "150000 kč",
            //imageSrc: "product2.jpg",
        },
        {
            id: 3,
            name: "LETADLO",
            description: "Lítá jako o závod.",
            price: "3000000 kč",
            //imageSrc: "letadlo.jpg"
        }
    ];

    productsData.forEach((productData) => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product');

        //const productImage = document.createElement('img');
       // productImage.src = productData.imageSrc;

        const productName = document.createElement('h2');
        productName.textContent = productData.name;

        const productDescription = document.createElement('p');
        productDescription.textContent = productData.description;

        const productPrice = document.createElement('p');
        productPrice.textContent = productData.price; 

        const addToCartButton = document.createElement('button');
        addToCartButton.textContent = 'Přidat do košíku';
        addToCartButton.dataset.productId = productData.id;

        addToCartButton.addEventListener('click', () => {
            addToCart({ ...productData, product_id: productData.id });
        });
        //productDiv.appendChild(productImage);
        productDiv.appendChild(productName);
        productDiv.appendChild(productDescription);
        productDiv.appendChild(productPrice);
        productDiv.appendChild(addToCartButton);

        productContainer.appendChild(productDiv);
    });

    function calculateTotalPrice() {
        let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
        let totalPrice = 0;


        cartItems.forEach(item => {
            totalPrice += parseFloat(item.price.replace(/\s+/g, '').replace(',', '.')); 
        });

        return totalPrice.toFixed(2); // Return the total price formatted with two decimal places
    }

    function updateTotalPrice() {
        let totalPrice = calculateTotalPrice();
        document.querySelector('.total-price').textContent = `Celková cena: ${totalPrice} kč`;
    }

    document.addEventListener('cartUpdated', updateTotalPrice);
    
    
    //přidání do košíku a do jsonu
     function addToCart(productData) {
        let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
        cartItems.push({ ...productData, product_id: productData.id });
        sessionStorage.setItem('cartItems', JSON.stringify(cartItems));
    
        console.log('Cart items in sessionStorage:', cartItems); //debug
    
        // produkt div a přiřazení informace
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
    
        const productName = document.createElement('p');
        productName.textContent = productData.name;
    
        const productPrice = document.createElement('p');
        productPrice.textContent = productData.price;
    
        const removeButton = document.createElement('button');
        removeButton.textContent = 'Odstranit z košíku';
        removeButton.addEventListener('click', () => {

        const index = cartItems.findIndex(item => item.name === productData.name);
        if (index !== -1) {
        cartItems.splice(index, 1);

        // update retezcce v sessionStorage 
        sessionStorage.setItem('cartItems', JSON.stringify(cartItems));

        cartItem.remove();

        updateCartQuantity();
    }

        });
    
        cartItem.appendChild(productName);
        cartItem.appendChild(productPrice);
        cartItem.appendChild(removeButton);
        shoppingList.appendChild(cartItem);
    
        // updatne pocet polozek v kosiku
        updateCartQuantity();
    }
 
     //počítání položek v košíku
     function updateCartQuantity() {
         const cartItems = document.querySelectorAll('.listCard .cart-item');
         quantitySpan.textContent = cartItems.length;
     }


    window.addEventListener('beforeunload', () => {
    // Clear sessionStorage on page refresh
    sessionStorage.setItem('pageRefreshed', 'true');
});

function sendCartToFinishPage() {
    let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
    let totalPrice = calculateTotalPrice();

    // Set cartItems as a cookie
    document.cookie = 'cartItems=' + encodeURIComponent(JSON.stringify(cartItems));

    // Set totalPrice as a separate cookie
    document.cookie = 'totalPrice=' + encodeURIComponent(totalPrice);

    if (cartItems.length === 0) {
        console.log('No cart items to send.');
        return;
    }

    // Clear sessionStorage after sending the information
    sessionStorage.removeItem('cartItems');

    // Redirect to the final page
    window.location.href = 'php/finishorder.php';
}


finishButton.addEventListener('click', () => {
    sendCartToFinishPage();
});

});



