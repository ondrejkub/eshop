<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrace</title>
    <style>
    body {
        background-color: #ecf2f3;
    }

    div {
    width:500px;
    background-color: #DCE0E1;
    padding: 2rem;
    margin:2rem auto;
    border:2px solid black;

    }
    input[type="text"],[type="email"],[type="password"] {
        position:center;
        width:100%;
        padding: 5px;
        font-size: 20px;
        border-radius: 5px;

        
    }

    h1 {
        text-align:center;
    }

    button {
        border: none;
        font-size: 16px;
        padding: 10px;
        margin: 20px auto;
        display: block;
        border-radius: 5px;
    }
    </style>

</head>
<body>
    <h1>REGISTRACE</h1>
    
   <div> 
    <form action="register_to_sql.php" method="post">
        <label for="name">Jméno</label>
        <input type="text" id="name" name="name" required>

        <label for="surname">Přijmení</label>
        <input type="text" id="surname" name="surname" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>

        <label for="password">Heslo</label>
        <input type="password" id="password" name="password" required>

        <label for="adress">Město</label>
        <input type="text" id="city" name="city" required>

        <label for="adress">Adresa</label>
        <input type="text" id="adress" name="adress" required>

        <label for="psc">PSČ</label>
        <input type="text" id="psc" name="psc" required>
        
        <button type="submit">Registrovat</button>

    </form>
    </div>


</body>
</html>