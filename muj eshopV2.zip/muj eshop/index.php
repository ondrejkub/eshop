<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css\eshopStyles.css">


</head>

<?php
session_start();

if (isset($_SESSION["email"])) {
    $loggedInUserEmail = $_SESSION["email"];
    $isLoggedIn = true;
} else {
    $isLoggedIn = false;
}
?>

<body>

<div class="container">
    <header>
        <h1>E-shop - Ondřej Kubíček</h1>

        <div class="shopping">
            <img src="obrázky\nákupní-košík.png" alt="Shopping Cart">
            <span class="quantity">0</span>
            
        </div>
    </header>
    <div class="login"><a href="php/login.php">Přihlášení</a></div>
    <div class="register"><a href="php/register.php">Registrace</a></div>
    
    <div class="products">


    </div>
</div>


<div class="card">
    <h1>Nákupní košík</h1>
    <ul class="listCard">
    </ul>
    <div class="checkOut">
        <div class="total"><a href="html\finishorder.html">Dokončit</a></div>
        <div class="closeShopping">Zavřít</div>
    </div>
</div>

<script src="js\eshop.js"></script>

<?php
    if ($isLoggedIn) {
        // Zobrazení informací o přihlášeném uživateli
        echo "prihlasen";
    } 
    ?>
</body>
</html>