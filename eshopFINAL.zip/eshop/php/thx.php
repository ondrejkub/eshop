<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Děkujeme!</title>
    <style>
        .home {
            float: left;
            height: 100%;
            width: 200px;
            font-size: medium;
            background-color: white;
            color: black;
            cursor: pointer;
        }

        .menu {
            height: 50px;
            align-items: center;
            background-color: black;
            color: white;
        }

        .thx {
            font-family:sans-serif;
            font-weight: bold;
            font-size:large;
            position: center;
            width:500px;
            padding: 2rem;
            margin:2rem auto;
            border:2px solid black;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="menu"> 
    <a href="../index.php"><button class="home" >Zpět na domovskou stránku</button></a>
</div>
<div>
    <div class="thx">Děkujeme Vám za vaši objednávku!
    </div>
</div>
</body>
</html>