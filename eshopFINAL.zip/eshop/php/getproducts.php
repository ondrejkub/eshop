<?php
session_start();

if (isset($_SESSION["email"])) {
    $isLoggedIn = true;
} else {
    $isLoggedIn = false;
}

if ($isLoggedIn == false) {
    header('location: ../index.php');  
}



require_once ('connection.php');

$conn = new mysqli($servername, $username, $password, $dbname);

// pripojeni
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// databaze s produkty
$sql = "SELECT * FROM produkty";
$result = $conn->query($sql);

$products = [];

if ($result === false) {
    die("Error executing the query: " . $conn->error);
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

$conn->close();

// json zbozi
header('Content-Type: application/json');
echo json_encode($products);
?>

