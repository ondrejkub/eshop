<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "Root_123";
$dbname = "eshop";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Kontrola připojení
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$totalPrice= 0;
//var_dump($_COOKIE);
//var_dump($_SESSION);

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_COOKIE['cartItems']) && isset($_SESSION['jmeno'])) {
        $cartItems = json_decode($_COOKIE['cartItems'], true);

        if (isset($_COOKIE['totalPrice'])) {
            $totalPrice = floatval($_COOKIE['totalPrice']);
        }

        // Insert order information into the 'objednavka' table
        $insertOrderQuery = "INSERT INTO objednavka (uzivatele_id_uzivatele, datum, stav, cena) VALUES (?, NOW(), 'v procesu', ?)";
        $stmt = mysqli_prepare($conn, $insertOrderQuery);
        $userId = $_SESSION['user_id'];

        mysqli_stmt_bind_param($stmt, "id", $userId, $totalPrice);

        if (mysqli_stmt_execute($stmt)) {
            $orderId = mysqli_insert_id($conn);

            // Insert each item into the 'polozka objednavky' table
            $insertItemQuery = "INSERT INTO `polozka objednavky` (objednavka_id_objednavky, produkty_ID_produktu, pocet_kusu, cena_za_polozku) VALUES (?, ?, ?, ?)";
            $stmtItem = mysqli_prepare($conn, $insertItemQuery);

            mysqli_stmt_bind_param($stmtItem, "iiid", $orderId, $item["product_id"], $item["quantity"], $item["price"]);

            foreach ($cartItems as $item) {
                // Check if product_id is not null before inserting
                if (isset($item["product_id"]) && $item["product_id"] !== null) {
                    mysqli_stmt_bind_param($stmtItem, "iiid", $orderId, $item["product_id"], $item["quantity"], $item["price"]);
            
                    if (mysqli_stmt_execute($stmtItem)) {
                        // Success for each item
                    } else {
                        echo "Error in item insertion: " . mysqli_error($conn);
                    }
                } else {
                    echo "Error in item insertion: Product ID is null or not set.";
                }
            }

            mysqli_stmt_close($stmtItem);

            echo '<div class="alert">Objednávka úspěšně uložena do databáze.</div>';
            session_destroy();
            exit;
            
        } else {
            echo "Error in order insertion: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
    } else {
        echo '<p>Unable to save order. Please check your session and cart items.</p>';
    }
}

if (isset($_COOKIE['cartItems'])) {
    $cartItems = json_decode($_COOKIE['cartItems'], true);
}

if (isset($_COOKIE['totalPrice'])) {
    $totalPrice = floatval($_COOKIE['totalPrice']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Objednávka</title>
    <style>
        body {
            background-color: #ecf2f3;
        }

        #orderSummary {
            width: 1000px;
            margin: auto;
            font-family: sans-serif;
        }

        .box {
            background-color: #DCE0E1;
            border: 1px solid #dddddd;
            padding: 10px;
            margin-bottom: 10px;
        }


        h2 {
            display: grid;
            grid-template-columns: 1fr 50px;
            text-align: center;
        }
    </style>
</head>
<body>
<div id="orderSummary">
    <h2>Shrnutí objednávky</h2>
    <?php
    echo '<h3><p>Informace o nakupujícím:</p></h3>';
    echo '<div class="box">';
    echo '<p><strong>Jméno:</strong> ' . $_SESSION['jmeno'] . ' ' . $_SESSION['prijmeni'] . '<br>' . '</p>';
    echo '<p><strong>Email:</strong> ' . $_SESSION['email'] . '<br>' . '</p>';
    echo '<p><strong>Adresa:</strong> ' . $_SESSION['adresa'] . ', ' . $_SESSION['mesto'] . '<br>' . '</p>';
    echo '<p><strong>PSČ:</strong> ' . $_SESSION['psc'] . '<br>' . '</p>';
    echo '</div>';

    if (isset($_COOKIE['cartItems'])) {
        $cartItems = json_decode($_COOKIE['cartItems'], true);
        echo '<h3><p>Položky nákupu: </p></h3>';
        echo '<div class="box">';
        foreach ($cartItems as $item) {
            echo '<p><strong>Položka:</strong> ' . $item["name"] . '</p>';
            echo '<p><strong>Cena:</strong> ' . $item["price"] . '</p>';
        }
        echo '</div>';

        echo '<h3><p>Doprava a platba: </p></h3>';
        echo '<div class="box">';
        echo '<p><strong>Platba: </strong>V tuto chvíli je podporována pouze platba dobírkou</p>';
        echo '<p><strong>Doručení: </strong>V tuto chvíli je podporováno doručení přes Balíkovnu</p>';
        echo '</div>';
        
        echo '<div><strong>Celková cena: </strong>' . $totalPrice . ' kč</div><br>';
    } else {
        echo '<p>Žádné zboží v košíku.</p>';
    }

    ?>
<br><form method="post" action="">
    <input type="submit" value="Odeslat objednávku">
</form>
</div>
</body>
</html>