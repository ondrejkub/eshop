<?php

$servername = "localhost";
$username = "root";
$password = "Root_123";
$dbname = "eshop";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get data from the form
$name = mysqli_real_escape_string($conn, $_POST['name']);
$surname = mysqli_real_escape_string($conn, $_POST['surname']);
$address = mysqli_real_escape_string($conn, $_POST['adress']);
$psc = mysqli_real_escape_string($conn, $_POST['psc']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$mesto = mysqli_real_escape_string($conn, $_POST['city']);

$password = password_hash($_POST['password'], PASSWORD_DEFAULT);


// Create and execute the prepared statement
$sql = "INSERT INTO uzivatele (jmeno, prijmeni, email, heslo, mesto, adresa, psc) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "ssssssi", $name, $surname, $email, $password, $mesto, $address, $psc);

if (mysqli_stmt_execute($stmt)) {
    header("Location: ../index.php");
        die();
} else {
    die("Error: " . mysqli_stmt_error($stmt));
}

// Close the statement and the database connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>



