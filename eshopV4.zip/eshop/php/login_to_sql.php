<?php
session_start(); 

$servername = "localhost";
$username = "root";
$password = "Root_123";
$dbname = "eshop";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Kontrola připojení
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = $_POST["email"];
$password = $_POST["password"];
$user_id = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Kontrola existence klíčů v poli $_POST
    if (isset($_POST["email"]) && isset($_POST["password"])) {
        $email = $_POST["email"];
        $password = $_POST["password"];

        // Získání uloženého hashovaného hesla a dalších údajů z databáze
        $sql = "SELECT id, heslo, jmeno, prijmeni, adresa, mesto, psc FROM uzivatele WHERE email = ?";
        
        
        $stmt = mysqli_prepare($conn, $sql);

        mysqli_stmt_bind_param($stmt, "s", $email);

       
        mysqli_stmt_execute($stmt);


        $result = mysqli_stmt_get_result($stmt);

        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $hashedPassword = $row['heslo'];
                $jmeno = $row['jmeno'];
                $prijmeni = $row['prijmeni'];
                $adresa = $row['adresa'];
                $mesto = $row['mesto'];
                $psc = $row['psc'];
                $user_id = $row['id'];
            } else {
                // Uživatel s daným emailem nebyl nalezen
                echo "uživatel nenalezen - nutno registrovat";
                exit();
            }
        } else {
            // Error in the query
            echo "Query failed: " . mysqli_error($conn);
            exit();
        }

        mysqli_stmt_close($stmt);
    } else {
        // Některé z klíčů nebyly předány při odesílání formuláře
        echo "Invalid request";
        exit();
    }

    // Porovnání zadaného hesla s uloženým hashem
    if (isset($hashedPassword) && password_verify($password, $hashedPassword)) {
        // Hesla se shodují - uživatel je přihlášen + ziskani uzivatelskych udaju 
        $_SESSION["email"] = $email;
        $_SESSION["jmeno"] = $jmeno;  
        $_SESSION["prijmeni"] = $prijmeni;
        $_SESSION["adresa"] = $adresa;
        $_SESSION["mesto"] = $mesto;
        $_SESSION["psc"] = $psc;
        $_SESSION['user_id'] = $user_id;
        
        header("Location: ../index.php");
        die();
    } else {
        // Neplatné přihlašovací údaje
        echo "Invalid username or password";
    }

    var_dump($_SESSION);
    var_dump($email, $hashedPassword, $jmeno, $prijmeni, $adresa, $mesto, $psc);
    var_dump($row);
} else {
    echo "Invalid request method.";
}
?>