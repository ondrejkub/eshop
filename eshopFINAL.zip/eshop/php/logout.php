<?php
session_start();

// Zrušení všech informací o relaci
session_unset();

// Zničení relace
session_destroy();

// Přesměrování na domovskou stránku 
header("Location: ../index.php");
exit();
?>