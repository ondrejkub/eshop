<?php

$servername = "localhost";
$username = "username"; //uzivatelske jmeno
$password = "password"; //heslo
$dbname = "eshop";

?>