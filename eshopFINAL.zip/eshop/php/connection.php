<?php

$servername = "localhost";
$username = "root"; //uzivatelske jmeno
$password = "root"; //heslo
$dbname = "eshop";

?>