document.addEventListener('DOMContentLoaded', function() //javascript se nacte az po nacteni strnaky (resi problem s kosikem)
{ 
    


let openShopping = document.querySelector('.shopping');
let closeShopping = document.querySelector('.closeShopping');
let products = document.querySelector('.list');
let listCard = document.querySelector('.listCard');
let body = document.querySelector('body');
let total = document.querySelector('.total');
let quantity = document.querySelector('.quantity');

openShopping.addEventListener('click', () => { //kliknu na obrazek kosiku a zpristupmnim kosik
    body.classList.add('active');
});

closeShopping.addEventListener('click', () => { //kliknu na box "Zavřít" a zavřu okno košík
    body.classList.remove('active');
});

console.log(openShopping);
console.log(listCard);

const productContainer = document.querySelector('.products');
const shoppingList = document.querySelector('.listCard');
const quantitySpan = document.querySelector('.quantity');
const shoppingCart = document.querySelector('.shopping');

function addToCart(productData) {
    const cartItem = document.createElement('div');
    cartItem.classList.add('cart-item');

    const productName = document.createElement('p');
    productName.textContent = productData.name;

    const productPrice = document.createElement('p');
    productPrice.textContent = productData.price;

    const removeButton = document.createElement('button');
    removeButton.textContent = 'Odstranit z košíku';
    removeButton.addEventListener('click', () => {
        cartItem.remove();
        updateCartQuantity();
    });


    cartItem.appendChild(productName);
    cartItem.appendChild(productPrice);
    cartItem.appendChild(removeButton);
    shoppingList.appendChild(cartItem);

    // Aktualizace počtu položek v košíku
    updateCartQuantity();
}

function updateCartQuantity() {
    const cartItems = document.querySelectorAll('.listCard .cart-item');
    quantitySpan.textContent = cartItems.length;

}

const productsData = [
    {
        name: "AUTO",
        description: "Pořádně rychlá kára.",
        price: "100 000 kč",
        imageSrc: "auto.jpg",
    },
    {
        name: "TRAKTOR",
        description: "Traktor pro pořádné farmáře.",
        price: "150 000 kč",
        imageSrc: "product2.jpg",
    },

    {
        name: "LETADLO",
        description: "Lítá jako o závod.",
        price: "3 000 000 kč",
        imageSrc: "letadlo.jpg"
    }
];

productsData.forEach((productData) => {
    const productDiv = document.createElement('div');
    productDiv.classList.add('product');

    const productImage = document.createElement('img');
    productImage.src = productData.imageSrc;

    const productName = document.createElement('h2');
    productName.textContent = productData.name;

    const productDescription = document.createElement('p');
    productDescription.textContent = productData.description;

    const productPrice = document.createElement('p');
    productPrice.textContent = productData.price;

    const addToCartButton = document.createElement('button');
    addToCartButton.textContent = 'Přidat do košíku';

    addToCartButton.addEventListener('click', () => {
        addToCart(productData);
    });



       
        productDiv.appendChild(productImage);
        productDiv.appendChild(productName);
        productDiv.appendChild(productDescription);
        productDiv.appendChild(productPrice);
        productDiv.appendChild(addToCartButton);
        
        productContainer.appendChild(productDiv);
    });


})

   