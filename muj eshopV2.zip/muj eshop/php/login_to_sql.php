<?php

$servername = "localhost";
$username = "root";
$password = "Root_123";
$dbname = "eshop";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();
$_SESSION["email"] = $email;
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Kontrola existence klíčů v poli $_POST
    if (isset($_POST["email"]) && isset($_POST["password"])) {
        $email = $_POST["email"];
        $password = $_POST["password"];

}
    // Porovnání zadaného hesla s uloženým hashem
    if (password_verify($password, $hashedPassword)) {
        // Hesla se shodují - uživatel je přihlášen
        $_SESSION["email"] = $email;
        
        header("Location: ../index.php");
        die();
    
        exit();
    } else {
        // Neplatné přihlašovací údaje
        echo "Invalid username or password";
    }
}
?>