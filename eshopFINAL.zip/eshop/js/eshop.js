document.addEventListener('DOMContentLoaded', function() {
    let openShopping = document.querySelector('.shopping');
    let closeShopping = document.querySelector('.closeShopping');
    let body = document.querySelector('body');
    let quantitySpan = document.querySelector('.quantity');
    let productContainer = document.querySelector('.products');
    let shoppingList = document.querySelector('.listCard');
    let finishButton = document.querySelector('.total');
 
    const pageRefreshed = sessionStorage.getItem('pageRefreshed');
    if (!pageRefreshed) {
        // Clear sessionStorage on page load if not refreshed
        sessionStorage.clear();
    }
    sessionStorage.setItem('pageRefreshed', 'false');



    //otevírání a zavírání košíku
    openShopping.addEventListener('click', () => {
        if (isLoggedIn === true) {
            body.classList.add('active');
        } else {
            alert('Pro přístup do košíku je potřeba být přihlášen.');
        }
    });
    
    closeShopping.addEventListener('click', () => { //kliknu na box "Zavřít" a zavřu okno košík
        body.classList.remove('active');
    });

    //tvoření divů s položkami
    const productsData = [
        {
            id: 1, //id
            name: "AUTO", //název
            description: "Pořádně rychlá kára.", //popis
            price: "100000 KČ", //cena
        },
        {
            id: 2,
            name: "TRAKTOR",
            description: "Traktor pro pořádné farmáře.",
            price: "150000 KČ",
        },
        {
            id: 3,
            name: "LETADLO",
            description: "Lítá jako o závod.",
            price: "3000000 KČ",
        }
    ];

    productsData.forEach((productData) => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product');

       // const productImage = document.createElement('img');
       // productImage.src = productData.imageSrc;

        const productName = document.createElement('h2');
        productName.textContent = productData.name;

        const productDescription = document.createElement('p');
        productDescription.textContent = productData.description;

        const productPrice = document.createElement('p');
        productPrice.textContent = productData.price; 

        const addToCartButton = document.createElement('button');
        addToCartButton.textContent = 'Přidat do košíku';
        addToCartButton.dataset.productId = productData.id;
        addToCartButton.classList.add('addToCartButton');

        addToCartButton.addEventListener('click', () => {
            addToCart({ ...productData, product_id: productData.id });
        });
       // productDiv.appendChild(productImage);
        productDiv.appendChild(productName);
        productDiv.appendChild(productDescription);
        productDiv.appendChild(productPrice);
        productDiv.appendChild(addToCartButton);

        productContainer.appendChild(productDiv);
    });

    //celková cena
    function calculateTotalPrice() {
        let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
        let totalPrice = 0;


        cartItems.forEach(item => {
            totalPrice += parseFloat(item.price.replace(/\s+/g, '').replace(',', '.')); 
        });

        return totalPrice.toFixed(2); // Return the total price formatted with two decimal places
    }

    function updateTotalPrice() {
        let totalPrice = calculateTotalPrice();
        document.querySelector('.total-price').textContent = `Celková cena: ${totalPrice} kč`;
    }

    document.addEventListener('cartUpdated', updateTotalPrice);
    
    
    //přidání do košíku a do jsonu
     function addToCart(productData) {
        let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
        cartItems.push({ ...productData, product_id: productData.id });
        sessionStorage.setItem('cartItems', JSON.stringify(cartItems));
    
        console.log('Cart items in sessionStorage:', cartItems); //debug

        //zpráva o přídání 
        const flashMessage = document.createElement('div');
        flashMessage.classList.add('flash-message');
        flashMessage.textContent = `Zboží bylo přidáno do košíku!`;
    
        // Append the flash message to the body
        document.body.appendChild(flashMessage);
    
        //odstranit zprávu
        setTimeout(() => {
            flashMessage.remove();
        }, 1000);
    
    
        // produkt div a přiřazení informace
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        
        const productInfoContainer = document.createElement('div');
        productInfoContainer.classList.add('product-info');
        
        const productName = document.createElement('p');
        productName.textContent = productData.name;
        
        const productPrice = document.createElement('p');
        productPrice.textContent = productData.price;
        
        const removeButton = document.createElement('button');
        removeButton.textContent = 'X';
        removeButton.classList.add('removeButton')
        removeButton.addEventListener('click', () => {
            const index = cartItems.findIndex(item => item.name === productData.name);
            if (index !== -1) {
                cartItems.splice(index, 1);
        
                // update retezcce v sessionStorage 
                sessionStorage.setItem('cartItems', JSON.stringify(cartItems));
        
                cartItem.remove();
        
                updateCartQuantity();
            }
        });
        
        productInfoContainer.appendChild(productName);
        productInfoContainer.appendChild(productPrice);
        
        cartItem.appendChild(productInfoContainer);
        cartItem.appendChild(removeButton);
        shoppingList.appendChild(cartItem);
    
        // updatne pocet polozek v kosiku
        updateCartQuantity();
    }
 
     //počítání položek v košíku
     function updateCartQuantity() {
         const cartItems = document.querySelectorAll('.listCard .cart-item');
         quantitySpan.textContent = cartItems.length;
     }


    window.addEventListener('beforeunload', () => {
    //refresh stranky smaze sessionstorage
    sessionStorage.setItem('pageRefreshed', 'true');
});

function sendCartToFinishPage() {
    let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
    let totalPrice = calculateTotalPrice();

    // susenky
    document.cookie = 'cartItems=' + encodeURIComponent(JSON.stringify(cartItems));

    // susenky 
    document.cookie = 'totalPrice=' + encodeURIComponent(totalPrice);

    if (cartItems.length === 0) {
        console.log('No cart items to send.');
        return;
    }

    //smnazat sessionstorage po dokonceni
    sessionStorage.removeItem('cartItems');

    //finalni strnka
    window.location.href = 'php/finishorder.php';
}


finishButton.addEventListener('click', () => {
    sendCartToFinishPage();
});

});



