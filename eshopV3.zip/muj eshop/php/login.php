<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Přihlášení</title>
    <style>
    body {
        background-color: #ecf2f3;
    }
    div {
    width:500px;
    background-color: #DCE0E1;
    padding: 2rem;
    margin:2rem auto;
    border:2px solid black;

    }
    input[type="text"],[type="email"],[type="password"] {
        position:center;
        width:100%;
        padding: 5px;
        font-size: 20px;
        border-radius: 5px;

        
    }

    h1 {
        text-align:center;
    }

    button {
        border: none;
        font-size: 16px;
        padding: 10px;
        margin: 20px auto;
        display: block;
        border-radius: 5px;
    }
    </style>

</head>
<body>
    <h1>PŘIHLÁŠENÍ</h1>
    
   <div> 
    <form action="login_to_sql.php" method="post">
        <label for="email">Email</label>
        <input type="email" id="email" name="email">

        <label for="password">Heslo</label>
        <input type="password" id="password" name="password">
        
        <button type="submit">Přihlásit</button>

    </form>
    </div>


</body>
</html>