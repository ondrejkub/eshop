<?php

session_start();


if (isset($_SESSION["email"])) {
    $isLoggedIn = true;
} else {
    $isLoggedIn = false;
}

if ($isLoggedIn == false) {
    header('location: ../index.php');  
}


require_once ('connection.php');

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Kontrola připojení
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$totalPrice= 0;
//var_dump($_COOKIE);
//var_dump($_SESSION);

//if jestli byl form poslan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_COOKIE['cartItems']) && isset($_SESSION['jmeno'])) {
        $cartItems = json_decode($_COOKIE['cartItems'], true);

        if (isset($_COOKIE['totalPrice'])) {
            $totalPrice = floatval($_COOKIE['totalPrice']);
        }

        // Insert do objednavka 
        $insertOrderQuery = "INSERT INTO objednavka (uzivatele_id_uzivatele, datum, stav, cena) VALUES (?, NOW(), 'v procesu', ?)";
        $stmt = mysqli_prepare($conn, $insertOrderQuery);
        $userId = $_SESSION['user_id'];

        mysqli_stmt_bind_param($stmt, "id", $userId, $totalPrice);

        if (mysqli_stmt_execute($stmt)) {
            $orderId = mysqli_insert_id($conn);

            // Insert do polozka objednavky
            $insertItemQuery = "INSERT INTO `polozka objednavky` (objednavka_id_objednavky, produkty_ID_produktu) VALUES (?, ?)";
            $stmtItem = mysqli_prepare($conn, $insertItemQuery);

            mysqli_stmt_bind_param($stmtItem, "id", $orderId, $item["product_id"]);

            foreach ($cartItems as $item) {
                //null nebo ne
                if (isset($item["product_id"]) && $item["product_id"] !== null) {
                    mysqli_stmt_bind_param($stmtItem, "id", $orderId, $item["product_id"]);
            
                    if (mysqli_stmt_execute($stmtItem)) {
                    } else {
                        echo "Error: " . mysqli_error($conn);
                    }
                } else {
                    echo "Error: Product ID není uloženo.";
                }
            }

            mysqli_stmt_close($stmtItem);

            echo '<div class="alert">Objednávka úspěšně uložena do databáze.</div>';

            header("Location: thx.php");

            session_destroy();
            exit;
            
        } else {
            echo "Error: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
    } else {
        echo '<p>nelze uložit objednávku.</p>';
    }
}

if (isset($_COOKIE['cartItems'])) {
    $cartItems = json_decode($_COOKIE['cartItems'], true);
}

if (isset($_COOKIE['totalPrice'])) {
    $totalPrice = floatval($_COOKIE['totalPrice']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Objednávka</title>
    <style>
        body {
            background-color: #ecf2f3;
        }

        #orderSummary {
            width: 1000px;
            margin: auto;
            font-family: sans-serif;
        }

        .box {
            background-color: #DCE0E1;
            border: 1px solid #dddddd;
            padding: 10px;
            margin-bottom: 10px;
        }


        h2 {
            display: grid;
            grid-template-columns: 1fr 50px;
            text-align: center;
        }

        .logout {
            float: right;
            height: 100%;
            width: 100px;
            cursor: pointer;
        }

        .home {
            float: left;
            height: 100%;
            width: 200px;
            font-size: medium;
            background-color: white;
            color: black;
            cursor: pointer;
        }

        .menu {
            height: 50px;
            align-items: center;
            background-color: black;
            color: white;
        }

        .submit {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 150px;
        }

    </style>
</head>
<body>
<div class="menu"> 
    <a href="../index.php"><button class="home" >Zpět na domovskou stránku</button></a>
    <a href="logout.php"><button class="logout">Odhlásit</button></a>
    </div>
<div id="orderSummary">
    <h2>Shrnutí objednávky</h2>
    <?php
    echo '<h3><p>Informace o nakupujícím:</p></h3>';
    echo '<div class="box">';
    echo '<p><strong>Jméno:</strong> ' . $_SESSION['jmeno'] . ' ' . $_SESSION['prijmeni'] . '<br>' . '</p>';
    echo '<p><strong>Email:</strong> ' . $_SESSION['email'] . '<br>' . '</p>';
    echo '<p><strong>Adresa:</strong> ' . $_SESSION['adresa'] . ', ' . $_SESSION['mesto'] . '<br>' . '</p>';
    echo '<p><strong>PSČ:</strong> ' . $_SESSION['psc'] . '<br>' . '</p>';
    echo '</div>';

    if (isset($_COOKIE['cartItems'])) {
        $cartItems = json_decode($_COOKIE['cartItems'], true);
        echo '<h3><p>Položky nákupu: </p></h3>';
        echo '<div class="box">';
        foreach ($cartItems as $item) {
            echo '<p><strong>Položka:</strong> ' . $item["název"] . '</p>';
            echo '<p><strong>Cena:</strong> ' . $item["cena"] . '</p>';
        }
        echo '</div>';

        echo '<h3><p>Doprava a platba: </p></h3>';
        echo '<div class="box">';
        echo '<p><strong>Platba: </strong>V tuto chvíli je podporována pouze platba dobírkou</p>';
        echo '<p><strong>Doručení: </strong>V tuto chvíli je podporováno doručení přes Balíkovnu</p>';
        echo '</div>';
        
        echo '<div><strong>Celková cena: </strong>' . $totalPrice . ' KČ</div><br>';
    } else {
        echo '<p>Žádné zboží v košíku.</p>';
    }

    ?>
<br><form class="submit" method="post" action="">
<button type="submit" class="submit">Odeslat objednávku</button>
</form>
</div>
</body>
</html>