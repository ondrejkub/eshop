<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrace</title>
    <style>
    body {
        background-color: #ecf2f3;
    }

    form {
    width:500px;
    background-color: #DCE0E1;
    padding: 2rem;
    margin:2rem auto;
    border:2px solid black;

    }
    input[type="text"],[type="email"],[type="password"] {
        position:center;
        width:100%;
        padding: 5px;
        font-size: 20px;
        border-radius: 5px;

        
    }

    h1 {
        text-align:center;
    }

    .submit {
        border: none;
        font-size: 16px;
        padding: 10px;
        margin: 20px auto;
        display: block;
        border-radius: 5px;
        cursor: pointer;
    }

        .home {
            float: left;
            height: 100%;
            width: 200px;
            font-size: medium;
            background-color: white;
            color: black;
            cursor: pointer;
        }

        .menu {
            height: 50px;
            align-items: center;
            background-color: black;
            color: white;
        }
    </style>

</head>
<body>
<div class="menu"> 
    <a href="../index.php"><button class="home" >Zpět na domovskou stránku</button></a>
</div>
    <h1>REGISTRACE</h1>
    
   <div class="form"> 
    <form action="register_to_sql.php" method="post">
        <label for="name">Jméno</label>
        <input type="text" id="name" name="name" required>

        <label for="surname">Přijmení</label>
        <input type="text" id="surname" name="surname" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>

        <label for="password">Heslo</label>
        <input type="password" id="password" name="password" required>

        <label for="adress">Město</label>
        <input type="text" id="city" name="city" required>

        <label for="adress">Adresa</label>
        <input type="text" id="adress" name="adress" required>

        <label for="psc">PSČ</label>
        <input type="text" id="psc" name="psc" required>
        
        <button class="submit" type="submit">Registrovat</button>

    </form>
    </div>


</body>
</html>