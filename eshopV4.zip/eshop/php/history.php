<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historie objednávek</title>
    <style>
         .logout {
            float: right;
            height: 100%;
            width: 100px;
            cursor: pointer;
        }

        .home {
            float: left;
            height: 100%;
            width: 200px;
            font-size: medium;
            background-color: white;
            color: black;
            cursor: pointer;
        }

        .menu {
            height: 50px;
            align-items: center;
            background-color: black;
            color: white;
        }

        .submit {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 150px;
        }

        .order {
            background-color: #DCE0E1;
            border: 1px solid #dddddd;
            padding: 10px;
            margin-bottom: 10px;
            width: 500px;
            position: center;
            margin: auto;
        }

        h1 {
            width:500px;
            text-align:center;
            margin:auto;
            margin-top:25px;
            margin-bottom:25px;
        }

    </style>    
</head>
<body>
<div class="menu"> 
    <a href="../index.php"><button class="home">Zpět na domovkou stránku</button></a>
    <a href="logout.php"><button class="logout">Odhlásit</button></a>
    </div>
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "Root_123";
$dbname = "eshop";

$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    $sql = "SELECT objednavka.datum, objednavka.stav, objednavka.cena,
        GROUP_CONCAT(produkty.název) AS product_names
        FROM objednavka
        JOIN `polozka objednavky` ON objednavka.id = `polozka objednavky`.objednavka_id_objednavky
        JOIN produkty ON `polozka objednavky`.produkty_ID_produktu = produkty.id
        WHERE objednavka.uzivatele_id_uzivatele = ?
        GROUP BY objednavka.id
        ORDER BY objednavka.datum DESC";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        die("Error: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    echo "<h1>Historie objednávek</h1>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='order'>";
        echo "<p><strong>Objednávka ze dne.:</strong> " . $row['datum'] . "</p>";
        echo "<p><strong>Produkty:</strong> " . $row['product_names'] . "</p>";
        echo "<p><strong>Celková cena:</strong> " . $row['total_price'] . "</p>";
        echo "<p><strong>Stav:</strong> " . $row['stav'] . "</p>";
        echo "</div>";
    }

    mysqli_stmt_close($stmt);
} else {
    echo "nepřihlášen.";
}

mysqli_close($conn);
?>

</body>
</html>