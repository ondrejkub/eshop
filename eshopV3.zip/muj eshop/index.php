<?php
session_start();

if (isset($_SESSION["email"])) {
    $isLoggedIn = true;
} else {
    $isLoggedIn = false;
}

//var_dump($isLoggedIn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eshop - Kubíček</title>
    <link rel="stylesheet" href="css/eshopStyles.css">
    <script>
      var isLoggedIn = <?php echo $isLoggedIn ? 'true' : 'false'; ?>;
</script>
<script src="js\eshop.js"></script>

</head>

<body>

<div class="container">
    <header>
        <h1>E-shop - Ondřej Kubíček</h1>

        <div class="shopping">
            <img src="obrázky\nákupní-košík.png" alt="Shopping Cart">
            <span class="quantity">0</span>
        </div>
    </header>

    <?php
    if ($isLoggedIn) {
        // Zobrazení informací o přihlášeném uživateli
        echo '<button class="logout"><a id="odhlasit" href="php/logout.php">Odhlásit</a></button>';
    } else {
        // Odkazy na přihlášení a registraci
        echo '<button class="login"><a href="php/login.php">Přihlášení</a></button>';
        echo '<button class="register"><a href="php/register.php">Registrace</a></button>';
    }
    
    if ($isLoggedIn) {
        //obsah košíku pouze pro přihlášené uživatele
        echo '<div class="products"></div>';
    }
    ?>
    
    <?php
    if ($isLoggedIn == false) {
    echo '<div class="alert">Pro nákup je nutné se přihlásit</div>';
    }


    ?>

</div>

<div class="card">
    <h1>Nákupní košík</h1>
    <ul class="listCard"></ul>
    <div class="checkOut">
        <button class="total">Dokončit</button>
        <button class="closeShopping">Zavřít</div>
    </div>
</div>


</body>
</html>